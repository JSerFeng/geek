import { mutations } from './mutations'
import {state} from './state'

export const userListStore = {
  state,
  mutations
}