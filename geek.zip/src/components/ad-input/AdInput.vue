<template>
    <input type="text">
</template>

<script lang="ts">

</script>

<style lang="scss">
    
</style>