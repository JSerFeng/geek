<template lang="">
     <div class="container">
      招生详情
    </div>
</template>

<script lang='ts'>
import { defineComponent } from "vue";

export default defineComponent({});
</script>

<style lang="scss">
    .container{
        text-align: center;
        font-size: 20px;
        line-height: 80px;
    }
</style>